import { Route, Routes } from "react-router-dom";
import LoginPage from "./pages/login/LoginPage";
import GamePage from "./pages/game/GamePage";
import CharacterSelectionPage from "./pages/character/CharacterSelectionPage";
import LandingPage from "./pages/landing/LandingPage";
import SignupPage from "./pages/signup/SignupPage";
import { useEffect } from "react";
import { useAuthStore } from "./stores/authStore";
import ProtectedRoute from "./components/ProtectedRoutes";

function App() {
  const verify = useAuthStore((s) => s.verify);
  useEffect(() => {
    verify();
  }, [verify]);
  return (
    <>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/signup" element={<SignupPage />} />
        <Route element={<ProtectedRoute />}>
          <Route path="/game" element={<GamePage />} />
          <Route path="/character" element={<CharacterSelectionPage />} />
        </Route>
      </Routes>
    </>
  );
}

export default App;
