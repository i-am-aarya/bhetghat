import axios, { AxiosError } from "axios";

const API_BASE = import.meta.env.VITE_GAME_SERVER;

const api = axios.create({
  baseURL: API_BASE,
  withCredentials: true,
});

// request interceptor: adds authorization header
api.interceptors.request.use((config) => {
  const token = localStorage.getItem("accessToken");
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// response interceptor: runs on every response that comes back
api.interceptors.response.use(
  // if success, return response as-is
  (response) => response,

  // if error, handle refresh token
  async (error: AxiosError) => {
    const originalRequest = error.config;

    if (!originalRequest || error.response?.status !== 401) {
      return Promise.reject(error);
    }

    // @ts-expect-error retry flag
    originalRequest._retry = true;

    try {
      const refreshToken = localStorage.getItem("refreshToken");
      if (!refreshToken) throw new Error("No refresh token");

      const { data } = await axios.post(`${API_BASE}/auth/v1/refresh`, {
        refreshToken,
      });

      localStorage.setItem("accessToken", data.accessToken);
      localStorage.setItem("refreshToken", data.refreshToken);

      originalRequest.headers.Accept = `Bearer ${data.accessToken}`;
      return api(originalRequest);
    } catch (error) {
      localStorage.removeItem("accessToken");
      localStorage.removeItem("refreshToken");
      window.location.href = "/login";

      return Promise.reject(error);
    }
  },
);

export default api;
