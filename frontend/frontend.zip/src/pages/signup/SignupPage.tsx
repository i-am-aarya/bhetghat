import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuthStore } from "@/stores/authStore";
import { Eye, EyeClosed } from "lucide-react";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";

interface RegisterFormData {
  email: string;
  password: string;
  username: string;
}

const SignupPage = () => {
  const navigate = useNavigate();
  const register = useAuthStore((s) => s.register);
  const isLoading = useAuthStore((s) => s.isLoading);
  const [error, setError] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [apiError, setApiError] = useState("");

  const {
    register: formRegister,
    handleSubmit,
    watch,
    formState: { errors, isSubmitting },
  } = useForm<RegisterFormData>();

  const password = watch("password");

  const onSubmit = async (data: RegisterFormData) => {
    setApiError("");
    try {
      await register({
        username: data.username,
        email: data.email,
        password: data.password,
      });

      navigate("/character");
    } catch (error) {
      // setApiError(error.response?.data?.message || "Registration Failed!");
      console.error(error);
    }
  };

  const submitting = isSubmitting || isLoading;

  return (
    <div className="w-screen h-screen flex justify-center items-center">
      {/*Registration Div*/}
      <form
        onSubmit={handleSubmit(onSubmit)}
        className="flex flex-col gap-4 outline rounded-xl p-5"
      >
        <div className="mb-5">
          <img
            src="/assets/icons/title-crisp.png"
            alt="BhetGhat Logo"
            // width={400}
            height={400}
            style={{ imageRendering: "pixelated" }}
          />
        </div>

        <div>
          <Input
            {...formRegister("email", {
              required: "Email is required",
              pattern: {
                value: /^\S+@\S+$/i,
                message: "invalid email",
              },
            })}
            type="email"
            placeholder="Enter your email"
          />
          {errors.email && (
            <span className="text-xs text-red-500">{errors.email.message}</span>
          )}
        </div>

        <div>
          <Input
            {...formRegister("username", {
              required: "username is required",
              minLength: { value: 4, message: "minimum 4 characters" },
            })}
            placeholder="username"
          />
          {errors.username && (
            <span className="text-xs text-red-500">
              {errors.username.message}
            </span>
          )}
        </div>

        <div>
          <div className="relative">
            <Input
              {...formRegister("password", {
                required: "password is required",
                minLength: { value: 8, message: "minimum 8 characters" },
              })}
              placeholder="password"
              type={showPassword ? "text" : "password"}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground"
            >
              {showPassword ? <Eye /> : <EyeClosed />}
            </button>
          </div>

          {errors.password && (
            <span className="text-xs text-red-500">
              {errors.password.message}
            </span>
          )}
        </div>

        <Button type="submit" disabled={submitting} className="w-full">
          {submitting ? "Creating Account ..." : "Sign Up"}
        </Button>
      </form>
    </div>
  );
};

export default SignupPage;
