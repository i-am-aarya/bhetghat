import { authApi, type RegisterPayload } from "@/api/auth";
import { create } from "zustand";

interface User {
  username: string;
  email: string;
  // spriteURL: string;
  id: string;
  firstname?: string;
  lastname?: string;
  isAdmin?: boolean;
}

interface AuthState {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  setUser: (user: User | null) => void;
  setLoading: (loading: boolean) => void;
  verify: () => Promise<void>;
  login: (email: string, password: string) => Promise<void>;
  register: (data: RegisterPayload) => Promise<void>;
  logout: () => Promise<void>;
}

interface Tokens {
  accessToken: string;
  refreshToken: string;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  isLoading: false,
  isAuthenticated: false,

  setUser: (user) => set({ user }),
  setLoading: (loading) => set({ isLoading: loading }),

  verify: async () => {
    try {
      const { data } = await authApi.verify();
      set({ user: data.user, isAuthenticated: true });
    } catch {
      set({ user: null, isAuthenticated: false });
    } finally {
      set({ isLoading: false });
    }
  },

  login: async (email, password) => {
    set({ isLoading: true });
    try {
      const { data } = await authApi.login({ email, password });
      setTokens(data.tokens);
      set({ user: data.user, isAuthenticated: true });
    } catch (error) {
      clearTokens();
      throw error;
    } finally {
      set({ isLoading: false });
    }
  },

  register: async (payload) => {
    set({ isLoading: true });
    try {
      const { data } = await authApi.register(payload);
      setTokens(data.tokens);
      set({ user: data.user, isAuthenticated: true });
    } catch (error) {
      clearTokens();
      throw error;
    } finally {
      set({ isLoading: false });
    }
  },

  logout: async () => {
    const refreshToken = localStorage.getItem("refreshToken");
    try {
      if (refreshToken) await authApi.logout(refreshToken);
    } catch (error) {
      console.error("logout error: ", error);
    } finally {
      clearTokens();
      set({ user: null, isAuthenticated: false });
    }
  },
}));
